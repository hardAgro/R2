<?php
require_once '_include/classes/Equipamentos.class.php';
require_once '_include/classes/Leituras.class.php';

$objLeit = new Leituras();

$valor = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_STRING);
//$valor = $_GET['status'];

if (is_null($valor) ) {
  //Gravar log de erros
  die("Dados inválidos");
} 

$explode = explode(",", $valor);
$equipamento = $explode[0];


//SELECT DA EQUIPAMENTO
$objEquip = new Equipamentos();
$result = $objEquip->querySelecionaEquipamentos($equipamento);

//SE MONITORAMENTO FOR IGUAL A "SO (SENSORES)" -> TB_LEITURAS
if($result['equi_tipo'] == 'SO'){
        
    $temperatura = $explode[1];
    $nutriente   = $explode[2];
    $umidade     = $explode[3];    
    $array=array("equipamento"=>$equipamento,"temperatura"=>$temperatura,"nutriente"=>$nutriente,"umidade"=>$umidade);                     
    $objLeit->queryInsertLeituras($array);
    
}else{ 
    //SE NÃO MONITORAMENTO É IGUAL A DT (PRAGAS) -> TB_LEITURASPRAGAS
    
    $praga = $result['prag_id'];
    $valor = $explode[1];    
    
    $array=array("equipamento"=>$equipamento,"praga"=>$praga,"valor"=>$valor); 
    $objLeit->queryInsertLeiturasPragas($array);
    
}
?>