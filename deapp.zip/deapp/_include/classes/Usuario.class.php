<?php

require_once 'Conexao.class.php';

class Usuario {
    
    private $con;
    private $objUsu;
    private $usu_id;
    private $usu_nome;
    private $usu_email;
    private $usu_usuario;
    private $usu_senha;
    private $usu_status;    
    private $usu_tipo;
    private $usu_datacadastro;
    
    public function __construct() {
        $this->con = new Conexao();
        //$this->objFunc = new Funcoes();       
    }
    
    public function __set($atributo, $valor) {
        $this->$atributo = $valor;
    }
    
    public function __get($atributo) {
        return $this->$atributo;
    }       
    
    public function logarUsuario($dados){        
        try{                     
            
                $this->usuario = $dados['usuario'];
                $this->senha   = sha1($dados['senha']);
                
                $cst = $this->con->conectar()->prepare("SELECT * FROM `tb_usuario` WHERE `usu_usuario` = :usuario AND `usu_senha` = :senha AND `usu_status` = 'AT';");
                
                $cst->bindParam(':usuario', $this->usuario, PDO::PARAM_STR);
                $cst->bindParam(':senha', $this->senha, PDO::PARAM_STR);                            
                $cst->execute();
                        if($cst->rowCount() == 0){
                                header('location: '.URL.'/login/error');
                        }else{
                                //session_start();
                                $rst = $cst->fetch();
                                $_SESSION['logado']   = "sim";
                                $_SESSION['usu_id']   = $rst['usu_id'];
                                $_SESSION['usu_tipo'] = $rst['usu_tipo'];
                                header("location: ".URL."/home");
                        }                
                
                            
            
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function usuarioLogado($dado){
            
            $this->usu_id   = $dado;    
            $cst = $this->con->conectar()->prepare("SELECT `usu_id`, `usu_nome`, `usu_email`, `usu_usuario` FROM `tb_usuario` WHERE `usu_id` = :usu_id;");
            $cst->bindParam(':usu_id', $this->usu_id, PDO::PARAM_INT);
            $cst->execute();
            $rst = $cst->fetch();
            $_SESSION['nome'] = $rst['usu_nome'];
            $_SESSION['foto'] = $rst['usu_usuario'];        
        
    }
    
    public function sairUsuario(){
            session_destroy();            
    }
    
    public function querySeleciona($dado){
        try{                       
            $this->usu_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_usuario` WHERE `usu_id` = :usu_id;");
            $cst->bindParam(":usu_id", $this->usu_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdate($dados){
        try{
            $objUsu = new Usuario();
            $result = $objUsu->querySeleciona($_SESSION['usu_id']);     
            
            $this->usu_id    = $_SESSION['usu_id'];
            $this->usu_email = $dados['email'];                        
            if($dados['senha'] == 'da39a3ee5e6b4b0d3255bfef95601890afd80709'){
                $this->usu_senha = $result['usu_senha'];
            }else{
                $this->usu_senha = sha1($dados['senha']);
            }            
            
            $cst = $this->con->conectar()->prepare("UPDATE `tb_usuario` SET  `usu_email` = :usu_email, `usu_senha` = :usu_senha WHERE `usu_id` = :usu_id;");
            $cst->bindParam(":usu_id", $this->usu_id, PDO::PARAM_INT);
            $cst->bindParam(":usu_email", $this->usu_email, PDO::PARAM_STR);
            $cst->bindParam(":usu_senha", $this->usu_senha, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    public function queryUpdateUsuario($dados){
        try{
            $objUsu = new Usuario();
            $result = $objUsu->querySeleciona($_SESSION['usu_id']);     
            
            $this->usu_id      = $dados['id'];
            $this->usu_nome    = $dados['nome'];
            $this->usu_email   = $dados['email'];            
            $this->usu_usuario = $dados['usuario'];
            $this->usu_senha   = sha1($dados['senha']);
            $this->usu_status  = $dados['status'];
            $this->usu_tipo    = $dados['tipo'];  
            
            if($dados['senha'] == 'da39a3ee5e6b4b0d3255bfef95601890afd80709' || $dados['senha'] == 'NULL' || $dados['senha'] == NULL){
                $this->usu_senha = $result['usu_senha'];
            }else{
                $this->usu_senha = sha1($dados['senha']);
            }            
            
            $cst = $this->con->conectar()->prepare("UPDATE `tb_usuario` SET  `usu_nome` = :usu_nome, `usu_email` = :usu_email, `usu_usuario` = :usu_usuario, `usu_senha` = :usu_senha, `usu_status` = :usu_status, `usu_tipo` = :usu_tipo WHERE `usu_id` = :usu_id;");
            $cst->bindParam(":usu_id", $this->usu_id, PDO::PARAM_INT);
            $cst->bindParam(":usu_nome", $this->usu_nome, PDO::PARAM_STR);
            $cst->bindParam(":usu_email", $this->usu_email, PDO::PARAM_STR);
            $cst->bindParam(":usu_usuario", $this->usu_usuario, PDO::PARAM_STR);
            $cst->bindParam(":usu_status", $this->usu_status, PDO::PARAM_STR);
            $cst->bindParam(":usu_tipo", $this->usu_tipo, PDO::PARAM_STR);
            $cst->bindParam(":usu_senha", $this->usu_senha, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function querySelect(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT * FROM `tb_usuario` WHERE usu_id != 1;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
   
    public function queryInsert($dados){
        try{
            $this->usu_nome         = $dados['nome'];
            $this->usu_email        = $dados['email'];            
            $this->usu_usuario      = $dados['usuario'];
            $this->usu_senha        = sha1($dados['senha']);
            $this->usu_status       = $dados['status'];
            $this->usu_tipo         = $dados['tipo'];                        
            $this->usu_datacadastro = date("Y-m-d H:i:s");
            $cst = $this->con->conectar()->prepare("INSERT INTO `tb_usuario` (`usu_nome`, `usu_email`, `usu_usuario`, `usu_senha`, `usu_status`, `usu_tipo`, `usu_datacadastro`) "
                    . "VALUES (:usu_nome, :usu_email, :usu_usuario, :usu_senha, :usu_status, :usu_tipo, :usu_datacadastro);");
            
            $cst->bindParam(":usu_nome", $this->usu_nome, PDO::PARAM_STR);
            $cst->bindParam(":usu_email", $this->usu_email, PDO::PARAM_STR);
            $cst->bindParam(":usu_usuario", $this->usu_usuario, PDO::PARAM_STR);
            $cst->bindParam(":usu_status", $this->usu_status, PDO::PARAM_STR);
            $cst->bindParam(":usu_tipo", $this->usu_tipo, PDO::PARAM_STR);
            $cst->bindParam(":usu_senha", $this->usu_senha, PDO::PARAM_STR);
            $cst->bindParam(":usu_datacadastro", $this->usu_datacadastro, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
}

?>