<?php

require_once 'Conexao.class.php';

class Equipamentos {
    
    private $con;
    private $objEquip;
    private $equi_id;
    private $solo_id;
    private $parc_id;    
    private $equi_nome;
    private $equi_localizacao;
    private $equi_tipo;    
    private $equi_atualizado;    
    
    public function __construct() {
        $this->con = new Conexao();
        //$this->objFunc = new Funcoes();       
    }
    
    public function __set($atributo, $valor) {
        $this->$atributo = $valor;
    }
    
    public function __get($atributo) {
        return $this->$atributo;
    }               
   
    public function queryInsertEquipamentos($dados){
        try{
            $this->parc_id          = $dados['parcela'];
            $this->solo_id          = $dados['solo'];
            $this->equi_nome        = utf8_decode($dados['nome']); 
            $this->equi_localizacao = utf8_decode($dados['localizacao']);
            $this->equi_tipo        = $dados['tipo'];            
            $this->equi_atualizado  = NULL;                        
            $cst = $this->con->conectar()->prepare("INSERT INTO `tb_equipamento` (`parc_id`,`solo_id`,`equi_nome`,`equi_localizacao`,`equi_tipo`,`equi_atualizado`) "
                                                 . "VALUES (:parc_id, :solo_id, :equi_nome, :equi_localizacao, :equi_tipo, :equi_atualizado);");             
            $cst->bindParam(":parc_id", $this->parc_id, PDO::PARAM_INT);
            $cst->bindParam(":solo_id", $this->solo_id, PDO::PARAM_INT);
            $cst->bindParam(":equi_nome", $this->equi_nome, PDO::PARAM_STR);
            $cst->bindParam(":equi_localizacao", $this->equi_localizacao, PDO::PARAM_STR);
            $cst->bindParam(":equi_tipo", $this->equi_tipo, PDO::PARAM_STR);            
            $cst->bindParam(":equi_atualizado", $this->equi_atualizado, PDO::PARAM_STR);
            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdateEquipamentos($dados){
        try{          
            
            $this->equi_id          = $dados['id'];
            $this->parc_id          = $dados['parcela'];
            $this->solo_id          = $dados['solo'];
            $this->equi_nome        = utf8_decode($dados['nome']); 
            $this->equi_localizacao = utf8_decode($dados['localizacao']);
            $this->equi_tipo        = $dados['tipo'];            
            $this->equi_atualizado  = date("Y-m-d H:i:s");    
            $cst = $this->con->conectar()->prepare("UPDATE `tb_equipamento` SET "
                    . "`parc_id` = :parc_id, "
                    . "`solo_id` = :solo_id, "
                    . "`equi_nome` = :equi_nome, "
                    . "`equi_localizacao` = :equi_localizacao, "
                    . "`equi_tipo` = :equi_tipo, "
                    . "`equi_atualizado` = :equi_atualizado WHERE `equi_id` = :equi_id;");
            $cst->bindParam(":equi_id", $this->equi_id, PDO::PARAM_INT);
            $cst->bindParam(":parc_id", $this->parc_id, PDO::PARAM_INT);
            $cst->bindParam(":solo_id", $this->solo_id, PDO::PARAM_INT);
            $cst->bindParam(":equi_nome", $this->equi_nome, PDO::PARAM_STR);
            $cst->bindParam(":equi_localizacao", $this->equi_localizacao, PDO::PARAM_STR);
            $cst->bindParam(":equi_tipo", $this->equi_tipo, PDO::PARAM_STR);            
            $cst->bindParam(":equi_atualizado", $this->equi_atualizado, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
                    
    public function querySelectEquipamentos(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT * FROM `tb_equipamento`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function querySelecionaEquipamentos($dado){
        try{                       
            $this->equi_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_equipamento` WHERE `equi_id` = :equi_id;");
            $cst->bindParam(":equi_id", $this->equi_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
     public function querySelecionaEquipamentosParcelas($dado){
        try{                       
            $this->parc_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_equipamento` WHERE `parc_id` = :parc_id;");
            $cst->bindParam(":parc_id", $this->parc_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
}

?>