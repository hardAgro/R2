<?php

require_once 'Conexao.class.php';

class Pragas {
    
    private $con;
    private $objPrag;
    private $cult_id;
    private $prag_id;
    private $prag_nome;
    private $prag_quantidade_min;
    private $prag_quantidade_max;
    
    public function __construct() {
        $this->con = new Conexao();
        //$this->objFunc = new Funcoes();       
    }
    
    public function __set($atributo, $valor) {
        $this->$atributo = $valor;
    }
    
    public function __get($atributo) {
        return $this->$atributo;
    }               
   
    public function queryInsertPragas($dados){
        try{
            
            $this->cult_id             = $dados['cultura'];
            $this->prag_nome           = utf8_decode($dados['nome']); 
            $this->prag_quantidade_min = $dados['minima'];
            $this->prag_quantidade_max = $dados['maxima'];
            $cst = $this->con->conectar()->prepare("INSERT INTO `tb_pragas` (`cult_id`,`prag_nome`,`prag_quantidade_min`,`prag_quantidade_max`) VALUES (:cult_id, :prag_nome, :prag_quantidade_min, :prag_quantidade_max);");            
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->bindParam(":prag_nome", $this->prag_nome, PDO::PARAM_STR);
            $cst->bindParam(":prag_quantidade_min", $this->prag_quantidade_min, PDO::PARAM_STR);
            $cst->bindParam(":prag_quantidade_max", $this->prag_quantidade_max, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdatePragas($dados){
        try{          
            $this->prag_id             = $dados['id'];
            $this->cult_id             = $dados['cultura'];
            $this->prag_nome           = utf8_decode($dados['nome']); 
            $this->prag_quantidade_min = $dados['minima'];
            $this->prag_quantidade_max = $dados['maxima'];
            $cst = $this->con->conectar()->prepare("UPDATE `tb_pragas` SET  `cult_id` = :cult_id, `prag_nome` = :prag_nome, `prag_quantidade_min` = :prag_quantidade_min, `prag_quantidade_max` = :prag_quantidade_max  WHERE `prag_id` = :prag_id;");
            $cst->bindParam(":prag_id", $this->prag_id, PDO::PARAM_INT);
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->bindParam(":prag_nome", $this->prag_nome, PDO::PARAM_STR);
            $cst->bindParam(":prag_quantidade_min", $this->prag_quantidade_min, PDO::PARAM_STR);
            $cst->bindParam(":prag_quantidade_max", $this->prag_quantidade_max, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
                    
    public function querySelectPragas(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT * FROM `tb_pragas`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function querySelecionaPragas($dado){
        try{                       
            $this->prag_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_pragas` WHERE `prag_id` = :prag_id;");
            $cst->bindParam(":prag_id", $this->prag_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
}

?>