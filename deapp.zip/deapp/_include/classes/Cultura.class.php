<?php

require_once 'Conexao.class.php';

class Cultura {
    
    private $con;
    private $objCult;
    private $cult_id;
    private $cult_nome;
    
    public function __construct() {
        $this->con = new Conexao();
        //$this->objFunc = new Funcoes();       
    }
    
    public function __set($atributo, $valor) {
        $this->$atributo = $valor;
    }
    
    public function __get($atributo) {
        return $this->$atributo;
    }       
    
    
   
    public function queryInsertCultura($dados){
        try{
            $this->cult_nome = utf8_decode($dados['nome']);
            $cst = $this->con->conectar()->prepare("INSERT INTO `tb_cultura` (`cult_nome`) VALUES (:cult_nome);");            
            $cst->bindParam(":cult_nome", $this->cult_nome, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdateCultura($dados){
        try{          
            $this->cult_id   = $dados['id'];
            $this->cult_nome = utf8_decode($dados['nome']); 
            $cst = $this->con->conectar()->prepare("UPDATE `tb_cultura` SET  `cult_nome` = :cult_nome WHERE `cult_id` = :cult_id;");
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->bindParam(":cult_nome", $this->cult_nome, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
                    
    public function querySelectCultura(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT * FROM `tb_cultura`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function querySelecionaCultura($dado){
        try{                       
            $this->cult_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_cultura` WHERE `cult_id` = :cult_id;");
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
}

?>