<?php

require_once 'Conexao.class.php';

class Solos {
    
    private $con;
    private $objSolo;
    private $cult_id;
    private $solo_id;
    private $solo_nome;
    private $solo_temperatura_min;
    private $solo_temperatura_max;    
    private $solo_umidade_min;
    private $solo_umidade_max;    
    private $solo_nutrientes_min;
    private $solo_nutrientes_max;
    
    public function __construct() {
        $this->con = new Conexao();
        //$this->objFunc = new Funcoes();       
    }
    
    public function __set($atributo, $valor) {
        $this->$atributo = $valor;
    }
    
    public function __get($atributo) {
        return $this->$atributo;
    }               
   
    public function queryInsertSolos($dados){
        try{
            
            $this->cult_id              = $dados['cultura'];
            $this->solo_nome            = utf8_decode($dados['nome']); 
            $this->solo_temperatura_min = $dados['temp_minima'];
            $this->solo_temperatura_max = $dados['temp_maxima'];            
            $this->solo_umidade_min = $dados['umid_minima'];
            $this->solo_umidade_max = $dados['umid_maxima'];            
            $this->solo_nutrientes_min = $dados['nutri_minima'];
            $this->solo_nutrientes_max = $dados['nutri_maxima'];
            
            $cst = $this->con->conectar()->prepare("INSERT INTO `tb_solo` (`cult_id`,`solo_nome`,`solo_temperatura_min`,`solo_temperatura_max`,`solo_umidade_min`,`solo_umidade_max`,`solo_nutrientes_min`,`solo_nutrientes_max`) "
                                                 . "VALUES (:cult_id, :solo_nome, :solo_temperatura_min, :solo_temperatura_max, :solo_umidade_min, :solo_umidade_max, :solo_nutrientes_min, :solo_nutrientes_max);"); 
            
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->bindParam(":solo_nome", $this->solo_nome, PDO::PARAM_STR);
            $cst->bindParam(":solo_temperatura_min", $this->solo_temperatura_min, PDO::PARAM_STR);
            $cst->bindParam(":solo_temperatura_max", $this->solo_temperatura_max, PDO::PARAM_STR);            
            $cst->bindParam(":solo_umidade_min", $this->solo_umidade_min, PDO::PARAM_STR);
            $cst->bindParam(":solo_umidade_max", $this->solo_umidade_max, PDO::PARAM_STR);            
            $cst->bindParam(":solo_nutrientes_min", $this->solo_nutrientes_min, PDO::PARAM_STR);
            $cst->bindParam(":solo_nutrientes_max", $this->solo_nutrientes_max, PDO::PARAM_STR);
            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdateSolos($dados){
        try{          
            
            $this->solo_id              = $dados['id'];
            $this->cult_id              = $dados['cultura'];
            $this->solo_nome            = utf8_decode($dados['nome']); 
            $this->solo_temperatura_min = $dados['temp_minima'];
            $this->solo_temperatura_max = $dados['temp_maxima'];            
            $this->solo_umidade_min = $dados['umid_minima'];
            $this->solo_umidade_max = $dados['umid_maxima'];            
            $this->solo_nutrientes_min = $dados['nutri_minima'];
            $this->solo_nutrientes_max = $dados['nutri_maxima'];
            $cst = $this->con->conectar()->prepare("UPDATE `tb_solo` SET  `cult_id` = :cult_id, "
                                                                        . "`solo_nome` = :solo_nome, "
                    . "`solo_temperatura_min` = :solo_temperatura_min, `solo_temperatura_max` = :solo_temperatura_max,"
                    . "`solo_umidade_min` = :solo_umidade_min, `solo_umidade_max` = :solo_umidade_max"
                    . ",`solo_nutrientes_min` = :solo_nutrientes_min,`solo_nutrientes_max` = :solo_nutrientes_max WHERE `solo_id` = :solo_id;");
            $cst->bindParam(":solo_id", $this->solo_id, PDO::PARAM_INT);
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->bindParam(":solo_nome", $this->solo_nome, PDO::PARAM_STR);
            $cst->bindParam(":solo_temperatura_min", $this->solo_temperatura_min, PDO::PARAM_STR);
            $cst->bindParam(":solo_temperatura_max", $this->solo_temperatura_max, PDO::PARAM_STR);            
            $cst->bindParam(":solo_umidade_min", $this->solo_umidade_min, PDO::PARAM_STR);
            $cst->bindParam(":solo_umidade_max", $this->solo_umidade_max, PDO::PARAM_STR);            
            $cst->bindParam(":solo_nutrientes_min", $this->solo_nutrientes_min, PDO::PARAM_STR);
            $cst->bindParam(":solo_nutrientes_max", $this->solo_nutrientes_max, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
                    
    public function querySelectSolos(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT * FROM `tb_solo`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function querySelecionaSolos($dado){
        try{                       
            $this->solo_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_solo` WHERE `solo_id` = :solo_id;");
            $cst->bindParam(":solo_id", $this->solo_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
}

?>