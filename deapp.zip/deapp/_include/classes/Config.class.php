<?php
session_start();

define("URL", "http://".$_SERVER["SERVER_NAME"].'/dae'); //DEFINO A URL DO SISTEMA

define("DIR_CSS", "/_include/estilos/lite/css");
define("DIR_IMG", "/_include/estilos/assets/imgages");
define("DIR_JS", "/_include/estilos/lite/js");
define("DIR_ESTILOS", "/_include/estilos");

define("SISTEMA", "DAE - DIAGNÓSTICO AVANÇADO DE ESTRESSE");
define("VERCAO", "1.0.0");
define("LICENCA", "");
define("CNPJ", "");
header('Content-Type: text/html; charset=utf-8');

date_default_timezone_set('America/Fortaleza');