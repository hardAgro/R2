<?php

require_once 'Conexao.class.php';

class Leituras {
    
    private $con;
    private $objLeit;
    private $leit_id;
    private $equip_id;
    private $leit_temperatura;
    private $leit_nutriente;
    private $leit_umidade;    
    private $leit_datahora;
    
    private $leitp_id;    
    private $prag_id;
    private $leitp_valor;
    private $leitp_datahora;
    
    public function __construct() {
        $this->con = new Conexao();
        //$this->objFunc = new Funcoes();       
    }
    
    public function __set($atributo, $valor) {
        $this->$atributo = $valor;
    }
    
    public function __get($atributo) {
        return $this->$atributo;
    }               
   
    public function queryInsertLeituras($dados){
        try{            
            $this->equip_id         = $dados['equipamento'];
            $this->leit_temperatura = $dados['temperatura']; 
            $this->leit_nutriente   = $dados['nutriente'];
            $this->leit_umidade     = $dados['umidade'];            
            $this->leit_datahora    = date("Y-m-d H:i:s");                
            $cst = $this->con->conectar()->prepare("INSERT INTO `tb_leituras` (`equip_id`,`leit_temperatura`,`leit_nutriente`,`leit_umidade`,`leit_datahora`) "
                                                 . "VALUES (:equip_id, :leit_temperatura, :leit_nutriente, :leit_umidade, :leit_datahora);");             
            $cst->bindParam(":equip_id", $this->equip_id, PDO::PARAM_INT);       
            $cst->bindParam(":leit_temperatura", $this->leit_temperatura, PDO::PARAM_STR);
            $cst->bindParam(":leit_nutriente", $this->leit_nutriente, PDO::PARAM_STR);            
            $cst->bindParam(":leit_umidade", $this->leit_umidade, PDO::PARAM_STR);
            $cst->bindParam(":leit_datahora", $this->leit_datahora, PDO::PARAM_STR);            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }   
    
    public function querySelecionaLeituras($dado){
        try{                       
            $this->cult_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_leituras` WHERE `cult_id` = :cult_id;");
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function querySelectLeituras($dado){
        try{                       
            $this->equip_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_leituras` WHERE `equip_id` = :equip_id ORDER BY `tb_leituras`.`leit_id` DESC LIMIT 1;");
            $cst->bindParam(":equip_id", $this->equip_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryInsertLeiturasPragas($dados){
        try{            
            $this->equip_id       = $dados['equipamento'];
            $this->prag_id        = $dados['praga'];
            $this->leitp_valor    = $dados['valor'];            
            $this->leitp_datahora = date("Y-m-d H:i:s");                
            $cst = $this->con->conectar()->prepare("INSERT INTO `tb_leituraspragas` (`equip_id`,`prag_id`,`leitp_valor`,`leitp_datahora`) "
                                                 . "VALUES (:equip_id, :prag_id, :leitp_valor, :leitp_datahora);");             
            $cst->bindParam(":equip_id", $this->equip_id, PDO::PARAM_INT);       
            $cst->bindParam(":prag_id", $this->prag_id, PDO::PARAM_INT);
            $cst->bindParam(":leitp_valor", $this->leitp_valor, PDO::PARAM_STR);            
            $cst->bindParam(":leitp_datahora", $this->leitp_datahora, PDO::PARAM_STR);            
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    } 
    
}

?>