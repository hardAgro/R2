<?php

require_once 'Conexao.class.php';

class Parcela {
    
    private $con;
    private $objParc;
    private $cult_id;
    private $parc_id;
    private $parc_identificacao;
    
    public function __construct() {
        $this->con = new Conexao();
        //$this->objFunc = new Funcoes();       
    }
    
    public function __set($atributo, $valor) {
        $this->$atributo = $valor;
    }
    
    public function __get($atributo) {
        return $this->$atributo;
    }               
   
    public function queryInsertParcela($dados){
        try{
            
            $this->cult_id            = $dados['cultura'];
            $this->parc_identificacao = utf8_decode($dados['nome']); 
            $cst = $this->con->conectar()->prepare("INSERT INTO `tb_parcela` (`cult_id`,`parc_identificacao`) VALUES (:cult_id, :parc_identificacao);");            
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->bindParam(":parc_identificacao", $this->parc_identificacao, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
    public function queryUpdateParcela($dados){
        try{          
            $this->parc_id            = $dados['id'];
            $this->cult_id            = $dados['cultura'];
            $this->parc_identificacao = utf8_decode($dados['nome']); 
            $cst = $this->con->conectar()->prepare("UPDATE `tb_parcela` SET  `parc_identificacao` = :parc_identificacao, `cult_id` = :cult_id WHERE `parc_id` = :parc_id;");
            $cst->bindParam(":parc_id", $this->parc_id, PDO::PARAM_INT);
            $cst->bindParam(":cult_id", $this->cult_id, PDO::PARAM_INT);
            $cst->bindParam(":parc_identificacao", $this->parc_identificacao, PDO::PARAM_STR);
            if($cst->execute()){
                return 'ok';
            }else{
                return 'erro';
            }
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
                    
    public function querySelectParcela(){
        try{
            $cst = $this->con->conectar()->prepare("SELECT * FROM `tb_parcela`;");
            $cst->execute();
            return $cst->fetchAll();
        } catch (PDOException $ex) {
            return 'erro '.$ex->getMessage();
        }
    }
    
    public function querySelecionaParcela($dado){
        try{                       
            $this->parc_id = $dado;            
            $cst = $this->con->conectar()->prepare("SELECT *  FROM `tb_parcela` WHERE `parc_id` = :parc_id;");
            $cst->bindParam(":parc_id", $this->parc_id, PDO::PARAM_INT);
            $cst->execute();
            $this->Count = $cst->rowCount();
            return $cst->fetch();
        } catch (PDOException $ex) {
            return 'error '.$ex->getMessage();
        }
    }
    
}

?>