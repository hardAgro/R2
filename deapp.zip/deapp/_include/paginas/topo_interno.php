<?php
if(isset($_SESSION['usu_tipo']) == 'ADM' || isset($_SESSION['usu_tipo']) == 'USU'){
    require_once '_include/classes/Usuario.class.php';
    $objUsu  = new Usuario();
    $objUsu->usuarioLogado($_SESSION['usu_id']);
}
?>

<body class="fix-header fix-sidebar card-no-border">

    <div id="main-wrapper">
        <header class="topbar">
            <nav class="navbar top-navbar navbar-toggleable-sm navbar-light">

                <div class="navbar-header">
                    <a class="navbar-brand" href="<?php echo  URL.'/home';?>">
                    </a>
                </div>
               
                <div class="navbar-collapse">
                   
                    <ul class="navbar-nav mr-auto mt-md-0"></ul>                                        
                    <ul class="navbar-nav my-lg-0">
                      
                        <li class="nav-item dropdown">
                            <a class="nav-link text-muted waves-effect waves-dark" href="<?php echo  URL.'/seuperfil';?>">
                                <?php echo $_SESSION['nome']; ?>
                            </a>
                        </li>
                    </ul>
                    
                </div>
            </nav>
        </header>