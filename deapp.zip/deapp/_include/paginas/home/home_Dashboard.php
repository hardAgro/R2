<?php
foreach ($objEquip->querySelectEquipamentos() as $resultados) {
    $resul_parcela  = $objParc->querySelecionaParcela($resultados['parc_id']);
    $result_cultura = $objCult->querySelecionaCultura($resul_parcela['cult_id']); 
?>
<div class="col-lg-4 col-md-5" style="float: left;">
    <div class="card">
        <div class="card-block">
            <h3 class="card-title">PARCELA: <?=  utf8_encode($resul_parcela['parc_identificacao']);?> </h3>
            <h6 class="card-subtitle">CULTURA: : <?=  utf8_encode($result_cultura['cult_nome']);?></h6>
                        
            <div id="info" style="height:220px; width:100%;">
                
                <table class="table">                                        
                    <tbody>   
                        
                        <?php
                        $leituras = $objLeit->querySelectLeituras($resultados['equi_id']);
                            $result_solo = $objSolo->querySelecionaSolos($resultados['solo_id']);
                            $umidade_min  = $result_solo['solo_umidade_min'];
                            $umidade_max  = $result_solo['solo_umidade_max'];
                        ?>                        
                        <tr>
                            <td><i class="mdi mdi-weather-hail"></i> <b>UMIDADE</b> </td>
                            <td>
                            <?php
                            $variavel = -1*$leituras['leit_umidade'];
                            
                            //METRICAS PARA TIPO DE SOLO
                            if($result_solo['solo_tipo']=='ARE'){
                                $log = ((-0.078*log($variavel))+0.0457);
                            }
                            
                            if($result_solo['solo_tipo']=='SIL'){
                                $log = ((-0.083*log($variavel))+0.1741);
                            }
                            
                            if($result_solo['solo_tipo']=='ARG'){
                                $log = ((-0.092*log($variavel))+0.3583);
                            }
                                                                                    
                            $leituraFinal = (round($log, 2)*100);   
                            
                            echo $leituraFinal.'%';
                                                                                   
                            if($leituraFinal < $umidade_min){
                                $alert = "text-danger";
                            }elseif($leituraFinal > $umidade_max){
                                $alert = "text-info";
                            }else{
                                $alert = "text-verde";
                            }
                            
                            ?>                            
                            </td>
                            <td class="text-center"><h6 class="<?=$alert;?>"><i class="fa fa-circle font-10 m-r-10 "></i></h6></td>
                        </tr>
                        <tr>
                            <td><i class="mdi mdi-thermometer"></i> <b>TEMP.</b> </td>
                            <td><?=$leituras['leit_temperatura'];?> °C</td>
                            <td class="text-center"><h6 class="text-muted text-info"><i class="fa fa-circle font-10 m-r-10 "></i></h6></td>
                        </tr>
                        <tr>
                            <td><i class="mdi mdi-shovel"></i> <b>NÍVEL DE SAIS</b> </td>
                            <td><?=$leituras['leit_nutriente'];?></td>
                            <td class="text-center"><h6 class="text-muted text-info"><i class="fa fa-circle font-10 m-r-10 "></i></h6></td>
                        </tr>
                        
                        <tr>
                            <td><i class="mdi mdi-bug"></i> <b>PRAGAS</b> </td>
                            <td></td>
                            <td class="text-center"><h6 class="text-muted text-info"><i class="fa fa-circle font-10 m-r-10 "></i></h6></td>
                        </tr>                             

                    </tbody>                    
                </table>
                
            </div>
            
        </div>
        <div>
            <hr class="m-t-0 m-b-0">
        </div>
        <div class="card-block text-center ">
            <ul class="list-inline m-b-0">                
                <li>
                    <h6 class="text-info"><i class="fa fa-circle font-10 m-r-10 "></i>Excesso</h6>
                </li>                
                <li>
                    <h6 class="text-verde"><i class="fa fa-circle font-10 m-r-10 "></i>Normal</h6>
                </li>
                <li>
                    <h6 class="text-danger"><i class="fa fa-circle font-10 m-r-10"></i>Dificiente</h6> 
                </li>
            </ul>
        </div>
    </div>
</div>
                
<?php
}
?>