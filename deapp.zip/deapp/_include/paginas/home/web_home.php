<?php     
require_once '_include/paginas/topo_interno.php';
require_once '_include/paginas/menu.php';
require_once '_include/classes/Parcela.class.php';
require_once '_include/classes/Cultura.class.php';
require_once '_include/classes/Equipamentos.class.php';
require_once '_include/classes/Leituras.class.php';
require_once '_include/classes/Solos.class.php';

$objParc  = new Parcela();
$objCult  = new Cultura();
$objEquip = new Equipamentos();
$objLeit  = new Leituras();
$objSolo  = new Solos();
?>
        <div class="page-wrapper">
            <div class="container-fluid">

                <div class="row page-titles">
                    <div class="col-md-5 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Dashboard</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-12">                        
                           
                            <?php require_once 'home_Dashboard.php'; ?>
                            
                    </div>
                </div>
                                
                
            </div>
                <?php require_once '_include/paginas/rodape_interno.php'; ?>
        </div>
    </div>