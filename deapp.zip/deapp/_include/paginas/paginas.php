     
    <!--AQUI PAGINAS DA VIEW-->
    <?php
    if(isset($_SESSION['logado']) && $_SESSION['logado']=='sim'){
       
        if($pagina==NULL){  $pagina = 'home'; }
        
        require_once '_include/paginas/'.$pagina.'/web_'.$pagina.'.php';                
        
    }else{
        
        $pagina = 'login';
        
        require_once '_include/paginas/'.$pagina.'/web_'.$pagina.'.php';        
        
    }
    ?> 