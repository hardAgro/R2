<aside class="left-sidebar">
        <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li> <a class="waves-effect waves-dark" href="<?php echo  URL.'/home/';?>" aria-expanded="false"><i class="mdi mdi-gauge"></i><span class="hide-menu">Dashboard</span></a>
                        </li>
                        <li> <a class="waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-account-check"></i><span class="hide-menu">Seu Perfil</span></a>
                        <?php
                        if(isset($_SESSION['usu_tipo']) AND $_SESSION['usu_tipo'] == 'ADM'){                            
                        ?>
                        </li>
                        <li>
                            <a class="waves-effect waves-dark" href="#" aria-expanded="false"><i class="mdi mdi-account-circle"></i><span class="hide-menu">Usuários</span></a>
                        </li>   
                        
                        <li>
                            <a class="waves-effect waves-dark" href="<?php echo  URL.'/cultura/';?>" aria-expanded="false"><i class="mdi mdi-attachment"></i><span class="hide-menu">Tipos de Cultura</span></a>
                        </li> 
                        
                        <li>
                            <a class="waves-effect waves-dark" href="<?php echo  URL.'/parcela/';?>" aria-expanded="false"><i class="mdi mdi-attachment"></i><span class="hide-menu">Parcela</span></a>
                        </li> 
                        
                        <li>
                            <a class="waves-effect waves-dark" href="<?php echo  URL.'/pragas/';?>" aria-expanded="false"><i class="mdi mdi-attachment"></i><span class="hide-menu">Tipos de Pragas</span></a>
                        </li>
                        
                        <li>
                            <a class="waves-effect waves-dark" href="<?php echo  URL.'/solos/';?>" aria-expanded="false"><i class="mdi mdi-attachment"></i><span class="hide-menu">Solos</span></a>
                        </li>
                        
                        <li>
                            <a class="waves-effect waves-dark" href="<?php echo  URL.'/equipamentos/';?>" aria-expanded="false"><i class=" icon-share"></i><span class="hide-menu">Equipamentos</span></a>
                        </li>  
                        <?php                            
                        }
                        ?>
                        
                        <li> <a class="waves-effect waves-dark" href="<?php echo  URL.'/relatorios';?>" aria-expanded="false"><i class="mdi mdi-file-outline"></i><span class="hide-menu">Relatórios</span></a>
                        </li> 
                        <li> <a class="waves-effect waves-dark" href="<?php echo  URL.'/ajuda';?>" aria-expanded="false"><i class="mdi mdi-help-circle"></i><span class="hide-menu">Ajuda/Sobre</span></a>
                        </li>
                    </ul>                    
                </nav>
            </div>           
            <div class="sidebar-footer">                
                <a href="<?php echo URL.'/sair'; ?>" class="link" data-toggle="tooltip" title="Logout"><i class="mdi mdi-power"></i></a> 
            </div>
</aside>

