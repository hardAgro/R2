<footer class="footer">
                © 2018 - <?php echo SISTEMA.' - '.VERCAO;?>
</footer>