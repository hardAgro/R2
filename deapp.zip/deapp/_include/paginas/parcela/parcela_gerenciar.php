<div class="card card-outline-info">

    

    <div class="card-block">

         <a href="<?php echo URL . '/' . $pagina . '/Cadastrar/'; ?>" class="btn btn-block btn-success">Cadastrar nova Parcela</a>
        <br>
        

        <h4 class="card-title">Parcelas</h4>
        <h6 class="card-subtitle">Cadastradas</h6>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome da Cultura</th>
                        <th>Identificação da Parcela</th>                        
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($objParc->querySelectParcela() as $resultados) {
                        $result_cultura = $objCult->querySelecionaCultura($resultados['cult_id']);
                    ?>
                    <tr>
                        <td><?=$resultados['parc_id'];?></td>
                        <td><?=  utf8_encode($result_cultura['cult_nome']);?></td>
                        <td><?=  utf8_encode($resultados['parc_identificacao']);?></td>
                        <td><a href="<?php echo URL . '/' . $pagina . '/Editar/'.$resultados['parc_id']; ?>" class="btn btn-success">Editar</a></td>
                    </tr> 
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>