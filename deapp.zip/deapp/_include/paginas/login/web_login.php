<?php
if(isset($acao) && $acao == 'logar'){    
        require_once '_include/classes/Usuario.class.php';
        $objUsu = new Usuario();
        $objUsu->logarUsuario($_POST);            
}
?>
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>  
    <section id="wrapper">
        <div class="login-register" style="background-color: #cccccc;">        
            <div class="login-box card">
            <div class="card-body">                
                <form class="form-horizontal form-material" id="loginform" name="loginform" action="<?php echo  URL.'/login/logar/';?>" method="POST">
                    <h3 class="box-title m-b-20">Faça Login!</h3>

                    <div class="form-group ">
                        <div class="col-xs-12">
                            <input name="usuario" class="form-control" type="text" required="" placeholder="Usuário"> </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input  name="senha" class="form-control" type="password" required="" placeholder="Senha"> </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="checkbox checkbox-primary pull-left p-t-0">                                
                            </div> <a href="#" id="to-recover" class="text-dark pull-right"><i class="fa fa-lock m-r-5"></i> Esqueceu sua senha?</a> </div>
                    </div>
                    <div class="form-group text-center m-t-20">
                        <div class="col-xs-12">
                            <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Entrar</button>
                        </div>
                    </div>
                    
                    <?php
                    if($acao == 'error'){
                    ?>                    
                        <div class="alert alert-danger"> <i class="ti-user"></i> Usuário ou senha não encontrados!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <span aria-hidden="true">×</span> </button>
                        </div>
                    <?php
                    }
                    //echo @$_SESSION['logado'].'<br>'.sha1(123456);
                    ?>
                </form>
                
            </div>
          </div>
        </div>
        
    </section>