<?php
$botao = $_POST['Botao'];
if(isset($_POST['id'])){ $id = $_POST['id']; }else{ $id = ''; }
?>
<div class="card card-outline-info">

    <a href="<?php echo URL . '/' . $pagina . '/'.$botao.'/'.$id; ?>" class="btn btn-block btn-info m-t-10"> <i class="mdi mdi-arrow-left-box"></i> Voltar</a>

    <div class="card-block">



        <h4 class="card-title">Controller</h4>
        <h6 class="card-subtitle">Pragas</h6>
        <div class="table-responsive">
            <?php            
                if(isset($botao) AND $botao == 'Cadastrar'){
                    if($objPrag->queryInsertPragas($_POST) == 'ok'){
                        echo "<meta http-equiv='refresh' content='0;URL=" . URL . "/" . $pagina . "/".$botao."/ok'>";
                    }else{
                        echo 'Falha ao inserir informações, tente novamente!';
                    }
                }
                if(isset($botao) AND $botao == 'Editar'){

                    if($objPrag->queryUpdatePragas($_POST) == 'ok'){
                        echo "<meta http-equiv='refresh' content='0;URL=" . URL . "/" . $pagina . "/".$botao."/".$_POST['id']."'>";
                    }else{
                        echo 'Falha ao inserir informações, tente novamente!';
                    }
                    
                }                    
            ?>
        </div>
    </div>
</div>