<div class="card card-outline-info">
    <div class="card-block">

        <a href="<?php echo URL . '/' . $pagina . '/'; ?>" class="btn btn-block btn-info m-t-10"> <i class="mdi mdi-arrow-left-box"></i> Voltar</a>
        <br>
        
        <h4 class="card-title">Cadastrar</h4>
        <h6 class="card-subtitle">Parcela</h6>
        <div class="table-responsive">
            
            <form class="form-horizontal form-material" id="cadastrar" name="cadastrar" action="<?php echo URL . '/'.$pagina.'/Controller/'; ?>" method="POST">
            
            <div class="form-group">
                <label class="col-sm-12">Tipo de Cultura</label>
                <div class="col-sm-12">
                    <select name="cultura" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>
                        <?php
                        foreach ($objCult->querySelectCultura() as $resultados) {
                        ?>
                        <option value="<?=$resultados['cult_id'];?>"><?=  utf8_encode($resultados['cult_nome']);?></option>
                        <?php } ?>
                    </select>
                </div>
            </div> 
                
                <div class="form-group">
                <label class="col-md-12">Identificação da Praga (nome)</label>
                <div class="col-md-12">
                    <input type="text" name="nome" required="" class="form-control form-control-line">
                </div>
                </div>            

                <div class="form-group" style="float: left;">
                <label class="col-md-12">Quant. Mínima</label>
                <div class="col-md-12">
                    <input type="number" step="any" name="minima" required="" class="form-control form-control-line">
                </div>
                </div>  
                
                <div class="form-group" style="float: left;">
                <label class="col-md-12">Quant. Máxima</label>
                <div class="col-md-12">
                    <input type="number" step="any" name="maxima" required="" class="form-control form-control-line">
                </div>
                </div>  
               
            <div class="form-group text-center col-md-12">
                <div class="col-md-12">
                    <button name="Botao" value="Cadastrar" class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Cadastrar</button>
                </div>
            </div>

        </form>
            
            
        </div>
    </div>
</div>