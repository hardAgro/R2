<?php
$resultado = $objPrag->querySelecionaPragas($id);
$count = $objPrag->Count; 
if($count!=1){
    echo "<meta http-equiv='refresh' content='0;URL=".URL."/".$pagina."'>";
}
?>
<div class="card card-outline-info">
    
    <div class="card-block">

        <a href="<?php echo URL . '/' . $pagina . '/'; ?>" class="btn btn-block btn-info m-t-10"> <i class="mdi mdi-arrow-left-box"></i> Voltar</a>
        <br>
        
        <h4 class="card-title">Editar</h4>
        <h6 class="card-subtitle">Cultura</h6>
        <div class="table-responsive">
            
            <form class="form-horizontal form-material" id="cadastrar" name="cadastrar" action="<?php echo URL . '/'.$pagina.'/Controller/'; ?>" method="POST">
           
                <div class="form-group">
                <label class="col-sm-12">Tipo de Cultura</label>
                <div class="col-sm-12">
                    <select name="cultura" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>
                        <?php
                        foreach ($objCult->querySelectCultura() as $result) {
                            if($resultado['cult_id'] == $result['cult_id']){ $selecione = 'selected'; }else{ $selecione = ''; }
                        ?>
                        <option <?=$selecione;?> value="<?=$result['cult_id'];?>"><?=  utf8_encode($result['cult_nome']);?></option>
                        <?php } ?>
                    </select>
                </div>
            </div> 
                
                <div class="form-group">
                <label class="col-md-12">Identificação da Praga (nome)</label>
                <div class="col-md-12">
                    <input type="text" name="nome" required="" value="<?=  utf8_encode($resultado['prag_nome']);?>" class="form-control form-control-line">
                </div>
                </div>     
                
                <div class="form-group" style="float: left;">
                <label class="col-md-12">Quant. Mínima</label>
                <div class="col-md-12">
                    <input type="number" step="any" name="minima" value="<?= $resultado['prag_quantidade_min'];?>" required="" class="form-control form-control-line">
                </div>
                </div>  
                
                <div class="form-group" style="float: left;">
                <label class="col-md-12">Quant. Máxima</label>
                <div class="col-md-12">
                    <input type="number" step="any" name="maxima" value="<?= $resultado['prag_quantidade_max'];?>" required="" class="form-control form-control-line">
                </div>
                </div> 

            <div class="form-group text-center col-md-12">
                <div class="col-md-12">
                    <input type="hidden" value="<?= $resultado['prag_id'];?>" name="id">
                    <button name="Botao" value="Editar" class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Alterar</button>
                </div>
            </div>

        </form>
            
            
        </div>
    </div>
</div>