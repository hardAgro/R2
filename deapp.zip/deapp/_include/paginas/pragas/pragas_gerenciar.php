<div class="card card-outline-info">

    

    <div class="card-block">

         <a href="<?php echo URL . '/' . $pagina . '/Cadastrar/'; ?>" class="btn btn-block btn-success">Cadastrar nova Praga</a>
        <br>
        

        <h4 class="card-title">Pragas</h4>
        <h6 class="card-subtitle">Cadastradas</h6>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome da Cultura</th>
                        <th>Praga Nome</th>                        
                        <th>Quant. Mínima</th>  
                        <th>Quant. Máxima</th>  
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($objPrag->querySelectPragas() as $resultados) {
                        $result_cultura = $objCult->querySelecionaCultura($resultados['cult_id']);
                    ?>
                    <tr>
                        <td><?=$resultados['prag_id'];?></td>
                        <td><?=utf8_encode($result_cultura['cult_nome']);?></td>
                        <td><?=utf8_encode($resultados['prag_nome']);?></td>
                        <td><?=$resultados['prag_quantidade_min'];?></td>
                        <td><?=$resultados['prag_quantidade_max'];?></td>
                        <td><a href="<?php echo URL . '/' . $pagina . '/Editar/'.$resultados['prag_id']; ?>" class="btn btn-success">Editar</a></td>
                    </tr> 
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>