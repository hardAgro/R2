<?php
$resultado = $objSolo->querySelecionaSolos($id);
$count = $objSolo->Count; 
if($count!=1){
    echo "<meta http-equiv='refresh' content='0;URL=".URL."/".$pagina."'>";
}
?>
<div class="card card-outline-info">
    
    <div class="card-block">

        <a href="<?php echo URL . '/' . $pagina . '/'; ?>" class="btn btn-block btn-info m-t-10"> <i class="mdi mdi-arrow-left-box"></i> Voltar</a>
        <br>
        
        <h4 class="card-title">Editar</h4>
        <h6 class="card-subtitle">Solo</h6>
        <div class="table-responsive">
            
            <form class="form-horizontal form-material" id="cadastrar" name="cadastrar" action="<?php echo URL . '/'.$pagina.'/Controller/'; ?>" method="POST">
           
                <div class="form-group">
                <label class="col-sm-12">Tipo de Cultura</label>
                <div class="col-sm-12">
                    <select name="cultura" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>
                        <?php
                        foreach ($objCult->querySelectCultura() as $result) {
                            if($resultado['cult_id'] == $result['cult_id']){ $selecione = 'selected'; }else{ $selecione = ''; }
                        ?>
                        <option <?=$selecione;?> value="<?=$result['cult_id'];?>"><?=  utf8_encode($result['cult_nome']);?></option>
                        <?php } ?>
                    </select>
                </div>
            </div> 
                
                <div class="form-group">
                <label class="col-md-12">Identificação do Solo (nome)</label>
                <div class="col-md-12">
                    <input type="text" name="nome" required="" value="<?=  utf8_encode($resultado['solo_nome']);?>" class="form-control form-control-line">
                </div>
                </div>     
                
                <div class="form-group col-md-12">
                    <div class="form-group" style="float: left;">
                    <label class="col-md-12">Temperatura Mínima</label>
                    <div class="col-md-12">
                        <input type="number" step="any" name="temp_minima" value="<?=$resultado['solo_temperatura_min'];?>" class="form-control form-control-line">
                    </div>
                    </div>

                    <div class="form-group" style="float: left;">
                    <label class="col-md-12">Temperatura Máxima</label>
                    <div class="col-md-12">
                        <input type="number" step="any" name="temp_maxima" value="<?=$resultado['solo_temperatura_max'];?>" class="form-control form-control-line">
                    </div>
                    </div>  
                </div>
                
                <div class="form-group col-md-12">
                    <div class="form-group" style="float: left;">
                    <label class="col-md-12">Umidade Mínima</label>
                    <div class="col-md-12">
                        <input type="number" step="any" name="umid_minima" value="<?=$resultado['solo_umidade_min'];?>" class="form-control form-control-line">
                    </div>
                    </div>

                    <div class="form-group" style="float: left;">
                    <label class="col-md-12">Umidade Máxima</label>
                    <div class="col-md-12">
                        <input type="number" step="any" name="umid_maxima" value="<?=$resultado['solo_umidade_max'];?>" class="form-control form-control-line">
                    </div>
                    </div>
                </div>
                
                <div class="form-group col-md-12">
                    <div class="form-group" style="float: left;">
                    <label class="col-md-12">Condutibilidade Mínimo</label>
                    <div class="col-md-12">
                        <input type="number" step="any" name="nutri_minima" value="<?=$resultado['solo_nutrientes_min'];?>" class="form-control form-control-line">
                    </div>
                    </div>

                    <div class="form-group" style="float: left;">
                    <label class="col-md-12">Condutibilidade Máxima</label>
                    <div class="col-md-12">
                        <input type="number" step="any" name="nutri_maxima" value="<?=$resultado['solo_nutrientes_max'];?>" class="form-control form-control-line">
                    </div>
                    </div>
                </div>

            <div class="form-group text-center col-md-12">
                <div class="col-md-12">
                    <input type="hidden" value="<?= $resultado['solo_id'];?>" name="id">
                    <button name="Botao" value="Editar" class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Alterar</button>
                </div>
            </div>

        </form>
            
            
        </div>
    </div>
</div>