<div class="card card-outline-info">

    

    <div class="card-block">

         <a href="<?php echo URL . '/' . $pagina . '/Cadastrar/'; ?>" class="btn btn-block btn-success">Cadastrar novo Solo</a>
        <br>
        

        <h4 class="card-title">Solos</h4>
        <h6 class="card-subtitle">Cadastradas</h6>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>Nome do Solo</th>   
                        <th>Cultura</th> 
                        <th class="text-center">Temp. Mín</th>  
                        <th class="text-center">Temp. Máx</th>  
                        <th class="text-center">Umid. Mín</th>  
                        <th class="text-center">Umid. Máx</th>  
                        <th class="text-center">Condu. Mín</th>  
                        <th class="text-center">Condu. Máx</th>  
                        <th class="text-center">Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($objSolo->querySelectSolos() as $resultados) {
                        $result_cultura = $objCult->querySelecionaCultura($resultados['cult_id']);
                    ?>
                    <tr>
                        <td class="text-center"><?=$resultados['solo_id'];?></td>
                        <td><?=utf8_encode($resultados['solo_nome']);?></td>
                        <td><?=utf8_encode($result_cultura['cult_nome']);?></td>
                        <td class="text-center"><?=$resultados['solo_temperatura_min'];?></td>
                        <td class="text-center"><?=$resultados['solo_temperatura_max'];?></td>
                        <td class="text-center"><?=$resultados['solo_umidade_min'];?></td>
                        <td class="text-center"><?=$resultados['solo_umidade_max'];?></td>
                        <td class="text-center"><?=$resultados['solo_nutrientes_min'];?></td>
                        <td class="text-center"><?=$resultados['solo_nutrientes_max'];?></td>
                        <td class="text-center"><a href="<?php echo URL . '/' . $pagina . '/Editar/'.$resultados['solo_id']; ?>" class="btn btn-success">Editar</a></td>
                    </tr> 
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>