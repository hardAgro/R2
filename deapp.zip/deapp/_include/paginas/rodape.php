    




<!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo  URL.''.DIR_ESTILOS;?>/assets/plugins/jquery/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo  URL.''.DIR_ESTILOS;?>/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo  URL.''.DIR_JS;?>/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo  URL.''.DIR_JS;?>/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo  URL.''.DIR_JS;?>/sidebarmenu.js"></script>
    <!--stickey kit -->
    <script src="<?php echo  URL.''.DIR_ESTILOS;?>/assets/plugins/sticky-kit-master/dist/sticky-kit.min.js"></script>
    
    <!--Custom JavaScript -->
    <script src="<?php echo  URL.''.DIR_JS;?>/custom.min.js"></script>
    <!-- ============================================================== -->  
    
    
</body>

</html>