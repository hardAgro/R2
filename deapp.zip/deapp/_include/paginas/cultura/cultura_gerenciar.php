<div class="card card-outline-info">

    

    <div class="card-block">

        <a href="<?php echo URL . '/' . $pagina . '/Cadastrar/'; ?>" class="btn btn-block btn-success">Cadastrar nova Cultura</a>
        <br>
        
        <h4 class="card-title">Culturas</h4>
        <h6 class="card-subtitle">Cadastradas</h6>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome da Cultura</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($objCult->querySelectCultura() as $resultados) {
                    ?>
                    <tr>
                        <td><?=$resultados['cult_id'];?></td>
                        <td><?=  utf8_encode($resultados['cult_nome']);?></td>
                        <td><a href="<?php echo URL . '/' . $pagina . '/Editar/'.$resultados['cult_id']; ?>" class="btn btn-success">Editar</a></td>
                    </tr> 
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>