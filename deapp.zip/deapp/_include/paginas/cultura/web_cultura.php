<?php     
require_once '_include/paginas/topo_interno.php';
require_once '_include/paginas/menu.php';
require_once '_include/classes/Cultura.class.php';

$objCult = new Cultura();

?>
        <div class="page-wrapper">
            <div class="container-fluid">

                <div class="row page-titles">
                    <div class="col-md-5 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Dashboard</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="">Dashboard</a></li>
                            <li class="breadcrumb-item active">Tipo de Cultura</li>
                        </ol>
                    </div>
                    
                </div>
                <div class="row">
                    <div class="col-12">
                        
                        <?php                              
                        
                        switch ($acao) {
        
                            case 'Cadastrar':
                                require_once 'cultura_cadastrar.php';
                                break;

                            case 'Editar':
                                require_once 'cultura_editar.php';
                                break;

                            case 'Controller':
                                require_once 'controller/cultura_controller.php';
                                break;

                             default:
                               require_once 'cultura_gerenciar.php';
                            }
                        ?>
                        
                    </div>
                </div>
                                
                
            </div>
                <?php require_once '_include/paginas/rodape_interno.php'; ?>
        </div>
    </div>