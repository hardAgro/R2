<?php
$botao = $_POST['Botao'];
?>
<div class="card card-outline-info">

    <a href="<?php echo URL . '/' . $pagina . '/'.$botao; ?>" class="btn btn-block btn-info m-t-10"> <i class="mdi mdi-arrow-left-box"></i> Voltar</a>

    <div class="card-block">



        <h4 class="card-title">Controller</h4>
        <h6 class="card-subtitle">Cultura</h6>
        <div class="table-responsive">
            <?php            
                if(isset($botao) AND $botao == 'Cadastrar'){
                    if($objCult->queryInsertCultura($_POST) == 'ok'){
                         echo "<meta http-equiv='refresh' content='0;URL=" . URL . "/" . $pagina . "/".$botao."/ok'>";
                    }else{
                        echo 'Falha ao inserir informações, tente novamente!';
                    }
                }
                if(isset($botao) AND $botao == 'Editar'){

                    if($objCult->queryUpdateCultura($_POST) == 'ok'){
                        echo "<meta http-equiv='refresh' content='0;URL=" . URL . "/" . $pagina . "/".$botao."/".$_POST['id']."'>";
                    }else{
                        echo 'Falha ao inserir informações, tente novamente!';
                    }
                    
                }                    
            ?>
        </div>
    </div>
</div>