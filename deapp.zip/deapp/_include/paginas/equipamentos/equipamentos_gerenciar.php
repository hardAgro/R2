<div class="card card-outline-info">

    

    <div class="card-block">

         <a href="<?php echo URL . '/' . $pagina . '/Cadastrar/'; ?>" class="btn btn-block btn-success">Cadastrar novo Equipamento</a>
        <br>
        

        <h4 class="card-title">Solos</h4>
        <h6 class="card-subtitle">Cadastradas</h6>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th class="text-center">#</th>
                        <th>Código</th> 
                        <th>Parcela</th> 
                        <th>Nome do Solo</th>                                           
                        <th>Localização</th>                                           
                        <th class="text-center">Ação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach ($objEquip->querySelectEquipamentos() as $resultados) {
                        $result_parcela = $objParc->querySelecionaParcela($resultados['parc_id']);
                        $result_solo    = $objSolo->querySelecionaSolos($resultados['solo_id']);
                    ?>
                    <tr>
                        <td class="text-center"><?=$resultados['equi_id'];?></td>
                        <td><?=$resultados['equi_nome'];?></td>
                        <td><?=utf8_encode($result_parcela['parc_identificacao']);?></td>
                        <td><?=utf8_encode($result_solo['solo_nome']);?></td>                       
                        <td><?=utf8_encode($resultados['equi_localizacao']);?></td>    
                        
                        
                        <td class="text-center"><a href="<?php echo URL . '/' . $pagina . '/Editar/'.$resultados['equi_id']; ?>" class="btn btn-success">Editar</a></td>
                    </tr> 
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>