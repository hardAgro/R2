<div class="card card-outline-info">
    <div class="card-block">

        <a href="<?php echo URL . '/' . $pagina . '/'; ?>" class="btn btn-block btn-info m-t-10"> <i class="mdi mdi-arrow-left-box"></i> Voltar</a>
        <br>
        
        <h4 class="card-title">Cadastrar</h4>
        <h6 class="card-subtitle">Equipamento</h6>
        <div class="table-responsive">
            
            <form class="form-horizontal form-material" id="cadastrar" name="cadastrar" action="<?php echo URL . '/'.$pagina.'/Controller/'; ?>" method="POST">
            
            <div class="form-group">
                <label class="col-sm-12">Parcela</label>
                <div class="col-sm-12">
                    <select name="parcela" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>
                        <?php
                        foreach ($objParc->querySelectParcela() as $resultados) {
                        ?>
                        <option value="<?=$resultados['parc_id'];?>"><?=  utf8_encode($resultados['parc_identificacao']);?></option>
                        <?php } ?>
                    </select>
                </div>
            </div> 
                
            <div class="form-group">
                <label class="col-sm-12">Solo</label>
                <div class="col-sm-12">
                    <select name="solo" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>
                        <?php
                        foreach ($objSolo->querySelectSolos() as $resultados) {
                        ?>
                        <option value="<?=$resultados['solo_id'];?>"><?=  utf8_encode($resultados['solo_nome']);?></option>
                        <?php } ?>
                    </select>
                </div>
            </div> 
                
            <div class="form-group">
                <label class="col-md-12">Identificação do Equipamento (nome)</label>
                <div class="col-md-12">
                    <input type="text" name="nome" required="" class="form-control form-control-line">
                </div>
            </div>            
            
            <div class="form-group">
                <label class="col-md-12">Localização do Equipamento</label>
                <div class="col-md-12">
                    <input type="text" name="localizacao" class="form-control form-control-line">
                </div>
            </div> 

            <div class="form-group">
                <label class="col-sm-12">Tipo Monitoramento</label>
                <div class="col-sm-12">
                    <select name="tipo" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>                        
                        <option value="SO">Monitoramento de Solo</option>
                        <option value="DT">Monitoramento de Pragas</option>
                    </select>
                </div>
            </div> 
               
            <div class="form-group text-center col-md-12">
                <div class="col-md-12">
                    <button name="Botao" value="Cadastrar" class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Cadastrar</button>
                </div>
            </div>

        </form>
            
            
        </div>
    </div>
</div>