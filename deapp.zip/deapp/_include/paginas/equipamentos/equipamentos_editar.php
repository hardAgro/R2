<?php
$resultado = $objEquip->querySelecionaEquipamentos($id);
$count = $objEquip->Count; 
if($count!=1){
    echo "<meta http-equiv='refresh' content='0;URL=".URL."/".$pagina."'>";
}
?>
<div class="card card-outline-info">
    
    <div class="card-block">

        <a href="<?php echo URL . '/' . $pagina . '/'; ?>" class="btn btn-block btn-info m-t-10"> <i class="mdi mdi-arrow-left-box"></i> Voltar</a>
        <br>
        
        <h4 class="card-title">Editar</h4>
        <h6 class="card-subtitle">Solo</h6>
        <div class="table-responsive">
            
            <form class="form-horizontal form-material" id="cadastrar" name="cadastrar" action="<?php echo URL . '/'.$pagina.'/Controller/'; ?>" method="POST">
                      
                <div class="form-group">
                <label class="col-sm-12">Parcela</label>
                <div class="col-sm-12">
                    <select name="parcela" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>
                        <?php
                        foreach ($objParc->querySelectParcela() as $result) {
                            if($resultado['parc_id'] == $result['parc_id']){ $selecione = 'selected'; }else{ $selecione = ''; }
                        ?>
                        <option <?=$selecione;?> value="<?=$result['parc_id'];?>"><?=  utf8_encode($result['parc_identificacao']);?></option>
                        <?php } ?>
                    </select>
                </div>
            </div> 
                
            <div class="form-group">
                <label class="col-sm-12">Solo</label>
                <div class="col-sm-12">
                    <select name="solo" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>
                        <?php
                        foreach ($objSolo->querySelectSolos() as $result) {
                             if($resultado['solo_id'] == $result['solo_id']){ $selecione = 'selected'; }else{ $selecione = ''; }
                        ?>
                        <option <?=$selecione;?> value="<?=$result['solo_id'];?>"><?=  utf8_encode($result['solo_nome']);?></option>
                        <?php } ?>
                    </select>
                </div>
            </div> 
                
            <div class="form-group">
                <label class="col-md-12">Identificação do Equipamento (nome)</label>
                <div class="col-md-12">
                    <input type="text" name="nome" required="" value="<?=utf8_encode($resultado['equi_nome']);?>" class="form-control form-control-line">
                </div>
            </div>            
            
            <div class="form-group">
                <label class="col-md-12">Localização do Equipamento</label>
                <div class="col-md-12">
                    <input type="text" name="localizacao" value="<?=utf8_encode($resultado['equi_localizacao']);?>" class="form-control form-control-line">
                </div>
            </div> 

            <div class="form-group">
                <label class="col-sm-12">Tipo Monitoramento</label>
                <div class="col-sm-12">
                    <select name="tipo" required="" class="form-control form-control-line">
                        <option value="">SELECIONE</option>                        
                        <option <?php  if($resultado['equi_tipo'] == 'SO'){ echo 'selected'; } ?> value="SO">Monitoramento de Solo</option>
                        <option <?php  if($resultado['equi_tipo'] == 'DT'){  echo 'selected'; } ?> value="DT">Monitoramento de Pragas</option>
                    </select>
                </div>
            </div> 
                
            <div class="form-group text-center col-md-12">
                <div class="col-md-12">
                    <input type="hidden" value="<?= $resultado['equi_id'];?>" name="id">
                    <button name="Botao" value="Editar" class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Alterar</button>
                </div>
            </div>

        </form>
            
            
        </div>
    </div>
</div>