<?php
require_once './_include/classes/Config.class.php';

require_once './_include/classes/Url.class.php';

$pagina   = Url::getURL(0);
$acao     = Url::getURL(1);
$id       = Url::getURL(2);
$id_dois  = Url::getURL(3);

require_once './_include/paginas/topo.php';

require_once './_include/paginas/paginas.php';

require_once './_include/paginas/rodape.php';
?>