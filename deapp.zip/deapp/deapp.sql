-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: 09-Dez-2018 às 18:59
-- Versão do servidor: 5.7.23
-- versão do PHP: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dae`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cultura`
--

DROP TABLE IF EXISTS `tb_cultura`;
CREATE TABLE IF NOT EXISTS `tb_cultura` (
  `cult_id` int(11) NOT NULL AUTO_INCREMENT,
  `cult_nome` varchar(200) NOT NULL,
  PRIMARY KEY (`cult_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_cultura`
--

INSERT INTO `tb_cultura` (`cult_id`, `cult_nome`) VALUES
(1, 'UVA'),
(2, 'MANGA');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_equipamento`
--

DROP TABLE IF EXISTS `tb_equipamento`;
CREATE TABLE IF NOT EXISTS `tb_equipamento` (
  `equi_id` int(11) NOT NULL AUTO_INCREMENT,
  `parc_id` int(11) DEFAULT NULL,
  `solo_id` int(11) DEFAULT NULL,
  `prag_id` int(11) DEFAULT NULL,
  `equi_nome` varchar(200) DEFAULT NULL,
  `equi_localizacao` varchar(200) DEFAULT NULL,
  `equi_tipo` enum('SO','DT') DEFAULT NULL,
  `equi_atualizado` datetime DEFAULT NULL,
  PRIMARY KEY (`equi_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_equipamento`
--

INSERT INTO `tb_equipamento` (`equi_id`, `parc_id`, `solo_id`, `prag_id`, `equi_nome`, `equi_localizacao`, `equi_tipo`, `equi_atualizado`) VALUES
(1, 1, 1, NULL, 'EQUIP001', '', 'SO', '2018-12-09 15:29:31'),
(2, 1, 2, 1, 'EQUIP002', '', 'DT', '2018-12-09 11:45:05');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_leituras`
--

DROP TABLE IF EXISTS `tb_leituras`;
CREATE TABLE IF NOT EXISTS `tb_leituras` (
  `leit_id` int(11) NOT NULL AUTO_INCREMENT,
  `equip_id` int(11) DEFAULT NULL,
  `leit_temperatura` float(5,2) DEFAULT NULL,
  `leit_nutriente` float(5,2) NOT NULL,
  `leit_umidade` float(5,2) NOT NULL,
  `leit_datahora` datetime DEFAULT NULL,
  PRIMARY KEY (`leit_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_leituras`
--

INSERT INTO `tb_leituras` (`leit_id`, `equip_id`, `leit_temperatura`, `leit_nutriente`, `leit_umidade`, `leit_datahora`) VALUES
(1, 1, 1.00, 2.00, 3.00, '2018-12-09 16:40:15'),
(2, 1, 20.00, 5.00, -0.20, '2018-12-09 16:40:25');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_leituraspragas`
--

DROP TABLE IF EXISTS `tb_leituraspragas`;
CREATE TABLE IF NOT EXISTS `tb_leituraspragas` (
  `leitp_id` int(11) NOT NULL AUTO_INCREMENT,
  `equip_id` int(11) DEFAULT NULL,
  `prag_id` int(11) DEFAULT NULL,
  `leitp_valor` float(5,2) DEFAULT NULL,
  `leitp_datahora` datetime DEFAULT NULL,
  PRIMARY KEY (`leitp_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_leituraspragas`
--

INSERT INTO `tb_leituraspragas` (`leitp_id`, `equip_id`, `prag_id`, `leitp_valor`, `leitp_datahora`) VALUES
(1, 2, 1, 1.00, '2018-12-09 16:59:47'),
(2, 2, 1, 2.00, '2018-12-09 16:59:58');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_parcela`
--

DROP TABLE IF EXISTS `tb_parcela`;
CREATE TABLE IF NOT EXISTS `tb_parcela` (
  `parc_id` int(11) NOT NULL AUTO_INCREMENT,
  `cult_id` int(11) NOT NULL,
  `parc_identificacao` varchar(200) NOT NULL,
  PRIMARY KEY (`parc_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_parcela`
--

INSERT INTO `tb_parcela` (`parc_id`, `cult_id`, `parc_identificacao`) VALUES
(1, 1, 'PAR001'),
(2, 1, 'PAR002');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_pragas`
--

DROP TABLE IF EXISTS `tb_pragas`;
CREATE TABLE IF NOT EXISTS `tb_pragas` (
  `prag_id` int(11) NOT NULL AUTO_INCREMENT,
  `cult_id` int(11) DEFAULT NULL,
  `prag_nome` varchar(200) DEFAULT NULL,
  `prag_quantidade_min` float(5,2) DEFAULT NULL,
  `prag_quantidade_max` float(5,2) DEFAULT NULL,
  PRIMARY KEY (`prag_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_pragas`
--

INSERT INTO `tb_pragas` (`prag_id`, `cult_id`, `prag_nome`, `prag_quantidade_min`, `prag_quantidade_max`) VALUES
(1, 1, 'MOSCA DAS FRUTAS', 11.00, 22.00);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_solo`
--

DROP TABLE IF EXISTS `tb_solo`;
CREATE TABLE IF NOT EXISTS `tb_solo` (
  `solo_id` int(11) NOT NULL AUTO_INCREMENT,
  `cult_id` int(11) DEFAULT NULL,
  `solo_nome` varchar(200) DEFAULT NULL,
  `solo_temperatura_min` float(5,2) DEFAULT NULL,
  `solo_temperatura_max` float(5,2) DEFAULT NULL,
  `solo_umidade_min` float(5,2) DEFAULT NULL,
  `solo_umidade_max` float(5,2) DEFAULT NULL,
  `solo_nutrientes_min` float(5,2) DEFAULT NULL,
  `solo_nutrientes_max` float(5,2) DEFAULT NULL,
  `solo_tipo` enum('ARE','SIL','ARG') NOT NULL,
  PRIMARY KEY (`solo_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_solo`
--

INSERT INTO `tb_solo` (`solo_id`, `cult_id`, `solo_nome`, `solo_temperatura_min`, `solo_temperatura_max`, `solo_umidade_min`, `solo_umidade_max`, `solo_nutrientes_min`, `solo_nutrientes_max`, `solo_tipo`) VALUES
(1, 1, 'SOLO ARENOSO', 20.05, 32.60, 8.00, 28.00, 50.51, 102.23, 'ARG'),
(2, 1, 'SOLO 02', 22.00, 34.00, 10.00, 16.00, 61.11, 70.50, 'ARE');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_usuario`
--

DROP TABLE IF EXISTS `tb_usuario`;
CREATE TABLE IF NOT EXISTS `tb_usuario` (
  `usu_id` int(11) NOT NULL AUTO_INCREMENT,
  `usu_nome` varchar(200) DEFAULT NULL,
  `usu_email` varchar(150) DEFAULT NULL,
  `usu_usuario` varchar(50) DEFAULT NULL,
  `usu_senha` varchar(150) DEFAULT NULL,
  `usu_status` enum('AT','IN') DEFAULT NULL,
  `usu_tipo` enum('ADM','USU') DEFAULT NULL,
  `usu_datacadastro` datetime DEFAULT NULL,
  PRIMARY KEY (`usu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tb_usuario`
--

INSERT INTO `tb_usuario` (`usu_id`, `usu_nome`, `usu_email`, `usu_usuario`, `usu_senha`, `usu_status`, `usu_tipo`, `usu_datacadastro`) VALUES
(1, 'ADMINISTRADOR', 'contato@fabvale.com.br', 'admin.fabvale', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'AT', 'ADM', '2018-12-09 01:00:00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
